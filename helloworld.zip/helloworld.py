
print('Hello World')
